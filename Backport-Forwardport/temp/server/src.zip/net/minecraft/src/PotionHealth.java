package net.minecraft.src;

public class PotionHealth extends Potion {
	public PotionHealth(int i1) {
		super(i1);
	}

	public boolean func_35437_a(int i1, int i2) {
		return i1 >= 1;
	}
}
