package net.minecraft.src;

public class WeightedRandomChoice {
	protected int field_35483_d;

	public WeightedRandomChoice(int i1) {
		this.field_35483_d = i1;
	}
}
