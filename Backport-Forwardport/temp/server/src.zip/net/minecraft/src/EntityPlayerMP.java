package net.minecraft.src;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import net.minecraft.server.MinecraftServer;

public class EntityPlayerMP extends EntityPlayer implements ICrafting {
	public NetServerHandler playerNetServerHandler;
	public MinecraftServer mcServer;
	public ItemInWorldManager itemInWorldManager;
	public double field_9155_d;
	public double field_9154_e;
	public List loadedChunks = new LinkedList();
	public Set field_420_ah = new HashSet();
	private int lastHealth = -99999999;
	private int field_35221_cc = -99999999;
	private boolean field_35222_cd = true;
	private int field_35220_ce = -99999999;
	private int ticksOfInvuln = 60;
	private ItemStack[] playerInventory = new ItemStack[]{null, null, null, null, null};
	private int currentWindowId = 0;
	public boolean isChangingQuantityOnly;
	public int field_35219_i;

	public EntityPlayerMP(MinecraftServer minecraftServer1, World world2, String string3, ItemInWorldManager itemInWorldManager4) {
		super(world2);
		itemInWorldManager4.thisPlayer = this;
		this.itemInWorldManager = itemInWorldManager4;
		ChunkCoordinates chunkCoordinates5 = world2.getSpawnPoint();
		int i6 = chunkCoordinates5.posX;
		int i7 = chunkCoordinates5.posZ;
		int i8 = chunkCoordinates5.posY;
		if(!world2.worldProvider.hasNoSky) {
			i6 += this.rand.nextInt(20) - 10;
			i8 = world2.findTopSolidBlock(i6, i7);
			i7 += this.rand.nextInt(20) - 10;
		}

		this.setLocationAndAngles((double)i6 + 0.5D, (double)i8, (double)i7 + 0.5D, 0.0F, 0.0F);
		this.mcServer = minecraftServer1;
		this.stepHeight = 0.0F;
		this.username = string3;
		this.yOffset = 0.0F;
	}

	public void readEntityFromNBT(NBTTagCompound nBTTagCompound1) {
		super.readEntityFromNBT(nBTTagCompound1);
		if(nBTTagCompound1.hasKey("playerGameType")) {
			this.itemInWorldManager.func_35696_a(nBTTagCompound1.getInteger("playerGameType"));
		}

	}

	public void writeEntityToNBT(NBTTagCompound nBTTagCompound1) {
		super.writeEntityToNBT(nBTTagCompound1);
		nBTTagCompound1.setInteger("playerGameType", this.itemInWorldManager.func_35697_a());
	}

	public void Sets(World world1) {
		super.Sets(world1);
	}

	public void func_20057_k() {
		this.currentCraftingInventory.onCraftGuiOpened(this);
	}

	public ItemStack[] getInventory() {
		return this.playerInventory;
	}

	protected void resetHeight() {
		this.yOffset = 0.0F;
	}

	public float getEyeHeight() {
		return 1.62F;
	}

	public void onUpdate() {
		this.itemInWorldManager.func_328_a();
		--this.ticksOfInvuln;
		this.currentCraftingInventory.updateCraftingResults();

		for(int i1 = 0; i1 < 5; ++i1) {
			ItemStack itemStack2 = this.getEquipmentInSlot(i1);
			if(itemStack2 != this.playerInventory[i1]) {
				this.mcServer.getEntityTracker(this.dimension).sendPacketToTrackedPlayers(this, new Packet5PlayerInventory(this.entityId, i1, itemStack2));
				this.playerInventory[i1] = itemStack2;
			}
		}

	}

	public ItemStack getEquipmentInSlot(int i1) {
		return i1 == 0 ? this.inventory.getCurrentItem() : this.inventory.armorInventory[i1 - 1];
	}

	public void onDeath(DamageSource damageSource1) {
		this.mcServer.configManager.sendPacketToAllPlayers(new Packet3Chat(damageSource1.func_35075_a(this)));
		this.inventory.dropAllItems();
	}

	public boolean attackEntityFrom(DamageSource damageSource1, int i2) {
		if(this.ticksOfInvuln > 0) {
			return false;
		} else {
			if(!this.mcServer.pvpOn && damageSource1 instanceof EntityDamageSource) {
				Entity entity3 = damageSource1.func_35080_a();
				if(entity3 instanceof EntityPlayer) {
					return false;
				}

				if(entity3 instanceof EntityArrow) {
					EntityArrow entityArrow4 = (EntityArrow)entity3;
					if(entityArrow4.shootingEntity instanceof EntityPlayer) {
						return false;
					}
				}
			}

			return super.attackEntityFrom(damageSource1, i2);
		}
	}

	protected boolean isPVPEnabled() {
		return this.mcServer.pvpOn;
	}

	public void heal(int i1) {
		super.heal(i1);
	}

	public void onUpdateEntity(boolean z1) {
		super.onUpdate();

		for(int i2 = 0; i2 < this.inventory.getSizeInventory(); ++i2) {
			ItemStack itemStack3 = this.inventory.getStackInSlot(i2);
			if(itemStack3 != null && Item.itemsList[itemStack3.itemID].func_28019_b() && this.playerNetServerHandler.getNumChunkDataPackets() <= 2) {
				Packet packet4 = ((ItemMapBase)Item.itemsList[itemStack3.itemID]).func_28022_b(itemStack3, this.worldObj, this);
				if(packet4 != null) {
					this.playerNetServerHandler.sendPacket(packet4);
				}
			}
		}

		if(z1 && !this.loadedChunks.isEmpty()) {
			ChunkCoordIntPair chunkCoordIntPair7 = (ChunkCoordIntPair)this.loadedChunks.get(0);
			if(chunkCoordIntPair7 != null) {
				boolean z8 = false;
				if(this.playerNetServerHandler.getNumChunkDataPackets() < 4) {
					z8 = true;
				}

				if(z8) {
					WorldServer worldServer9 = this.mcServer.getWorldManager(this.dimension);
					this.loadedChunks.remove(chunkCoordIntPair7);
					NetServerHandler netServerHandler10000 = this.playerNetServerHandler;
					int i10003 = chunkCoordIntPair7.chunkXPos * 16;
					int i10005 = chunkCoordIntPair7.chunkZPos * 16;
					worldServer9.getClass();
					netServerHandler10000.sendPacket(new Packet51MapChunk(i10003, 0, i10005, 16, 128, 16, worldServer9));
					int i10001 = chunkCoordIntPair7.chunkXPos * 16;
					i10003 = chunkCoordIntPair7.chunkZPos * 16;
					int i10004 = chunkCoordIntPair7.chunkXPos * 16 + 16;
					worldServer9.getClass();
					List list5 = worldServer9.getTileEntityList(i10001, 0, i10003, i10004, 128, chunkCoordIntPair7.chunkZPos * 16 + 16);

					for(int i6 = 0; i6 < list5.size(); ++i6) {
						this.getTileEntityInfo((TileEntity)list5.get(i6));
					}
				}
			}
		}

		if(this.inPortal) {
			if(this.mcServer.propertyManagerObj.getBooleanProperty("allow-nether", true)) {
				if(this.currentCraftingInventory != this.personalCraftingInventory) {
					this.usePersonalCraftingInventory();
				}

				if(this.ridingEntity != null) {
					this.mountEntity(this.ridingEntity);
				} else {
					this.timeInPortal += 0.0125F;
					if(this.timeInPortal >= 1.0F) {
						this.timeInPortal = 1.0F;
						this.timeUntilPortal = 10;
						this.mcServer.configManager.sendPlayerToOtherDimension(this);
						this.field_35220_ce = -1;
						this.lastHealth = -1;
						this.field_35221_cc = -1;
					}
				}

				this.inPortal = false;
			}
		} else {
			if(this.timeInPortal > 0.0F) {
				this.timeInPortal -= 0.05F;
			}

			if(this.timeInPortal < 0.0F) {
				this.timeInPortal = 0.0F;
			}
		}

		if(this.timeUntilPortal > 0) {
			--this.timeUntilPortal;
		}

		if(this.health != this.lastHealth || this.field_35221_cc != this.field_35217_m.func_35585_a() || this.field_35217_m.func_35586_c() == 0.0F != this.field_35222_cd) {
			this.playerNetServerHandler.sendPacket(new Packet8UpdateHealth(this.health, this.field_35217_m.func_35585_a(), this.field_35217_m.func_35586_c()));
			this.lastHealth = this.health;
			this.field_35221_cc = this.field_35217_m.func_35585_a();
			this.field_35222_cd = this.field_35217_m.func_35586_c() == 0.0F;
		}

		if(this.field_35212_N != this.field_35220_ce) {
			this.field_35220_ce = this.field_35212_N;
			this.playerNetServerHandler.sendPacket(new Packet43Experience(this.field_35210_L, this.field_35212_N, this.field_35211_M));
		}

	}

	private void getTileEntityInfo(TileEntity tileEntity1) {
		if(tileEntity1 != null) {
			Packet packet2 = tileEntity1.getDescriptionPacket();
			if(packet2 != null) {
				this.playerNetServerHandler.sendPacket(packet2);
			}
		}

	}

	public void onItemPickup(Entity entity1, int i2) {
		if(!entity1.isDead) {
			EntityTracker entityTracker3 = this.mcServer.getEntityTracker(this.dimension);
			if(entity1 instanceof EntityItem) {
				entityTracker3.sendPacketToTrackedPlayers(entity1, new Packet22Collect(entity1.entityId, this.entityId));
			}

			if(entity1 instanceof EntityArrow) {
				entityTracker3.sendPacketToTrackedPlayers(entity1, new Packet22Collect(entity1.entityId, this.entityId));
			}

			if(entity1 instanceof EntityXPOrb) {
				entityTracker3.sendPacketToTrackedPlayers(entity1, new Packet22Collect(entity1.entityId, this.entityId));
			}
		}

		super.onItemPickup(entity1, i2);
		this.currentCraftingInventory.updateCraftingResults();
	}

	public void swingItem() {
		if(!this.isSwinging) {
			this.swingProgressInt = -1;
			this.isSwinging = true;
			EntityTracker entityTracker1 = this.mcServer.getEntityTracker(this.dimension);
			entityTracker1.sendPacketToTrackedPlayers(this, new Packet18Animation(this, 1));
		}

	}

	public void func_22068_s() {
	}

	public EnumStatus sleepInBedAt(int i1, int i2, int i3) {
		EnumStatus enumStatus4 = super.sleepInBedAt(i1, i2, i3);
		if(enumStatus4 == EnumStatus.OK) {
			EntityTracker entityTracker5 = this.mcServer.getEntityTracker(this.dimension);
			Packet17Sleep packet17Sleep6 = new Packet17Sleep(this, 0, i1, i2, i3);
			entityTracker5.sendPacketToTrackedPlayers(this, packet17Sleep6);
			this.playerNetServerHandler.teleportTo(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
			this.playerNetServerHandler.sendPacket(packet17Sleep6);
		}

		return enumStatus4;
	}

	public void wakeUpPlayer(boolean z1, boolean z2, boolean z3) {
		if(this.isPlayerSleeping()) {
			EntityTracker entityTracker4 = this.mcServer.getEntityTracker(this.dimension);
			entityTracker4.sendPacketToTrackedPlayersAndTrackedEntity(this, new Packet18Animation(this, 3));
		}

		super.wakeUpPlayer(z1, z2, z3);
		if(this.playerNetServerHandler != null) {
			this.playerNetServerHandler.teleportTo(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
		}

	}

	public void mountEntity(Entity entity1) {
		super.mountEntity(entity1);
		this.playerNetServerHandler.sendPacket(new Packet39AttachEntity(this, this.ridingEntity));
		this.playerNetServerHandler.teleportTo(this.posX, this.posY, this.posZ, this.rotationYaw, this.rotationPitch);
	}

	protected void updateFallState(double d1, boolean z3) {
	}

	public void handleFalling(double d1, boolean z3) {
		super.updateFallState(d1, z3);
	}

	private void getNextWidowId() {
		this.currentWindowId = this.currentWindowId % 100 + 1;
	}

	public void displayWorkbenchGUI(int i1, int i2, int i3) {
		this.getNextWidowId();
		this.playerNetServerHandler.sendPacket(new Packet100OpenWindow(this.currentWindowId, 1, "Crafting", 9));
		this.currentCraftingInventory = new ContainerWorkbench(this.inventory, this.worldObj, i1, i2, i3);
		this.currentCraftingInventory.windowId = this.currentWindowId;
		this.currentCraftingInventory.onCraftGuiOpened(this);
	}

	public void displayGUIChest(IInventory iInventory1) {
		this.getNextWidowId();
		this.playerNetServerHandler.sendPacket(new Packet100OpenWindow(this.currentWindowId, 0, iInventory1.getInvName(), iInventory1.getSizeInventory()));
		this.currentCraftingInventory = new ContainerChest(this.inventory, iInventory1);
		this.currentCraftingInventory.windowId = this.currentWindowId;
		this.currentCraftingInventory.onCraftGuiOpened(this);
	}

	public void displayGUIFurnace(TileEntityFurnace tileEntityFurnace1) {
		this.getNextWidowId();
		this.playerNetServerHandler.sendPacket(new Packet100OpenWindow(this.currentWindowId, 2, tileEntityFurnace1.getInvName(), tileEntityFurnace1.getSizeInventory()));
		this.currentCraftingInventory = new ContainerFurnace(this.inventory, tileEntityFurnace1);
		this.currentCraftingInventory.windowId = this.currentWindowId;
		this.currentCraftingInventory.onCraftGuiOpened(this);
	}

	public void displayGUIDispenser(TileEntityDispenser tileEntityDispenser1) {
		this.getNextWidowId();
		this.playerNetServerHandler.sendPacket(new Packet100OpenWindow(this.currentWindowId, 3, tileEntityDispenser1.getInvName(), tileEntityDispenser1.getSizeInventory()));
		this.currentCraftingInventory = new ContainerDispenser(this.inventory, tileEntityDispenser1);
		this.currentCraftingInventory.windowId = this.currentWindowId;
		this.currentCraftingInventory.onCraftGuiOpened(this);
	}

	public void updateCraftingInventorySlot(Container container1, int i2, ItemStack itemStack3) {
		if(!(container1.getSlot(i2) instanceof SlotCrafting)) {
			if(!this.isChangingQuantityOnly) {
				this.playerNetServerHandler.sendPacket(new Packet103SetSlot(container1.windowId, i2, itemStack3));
			}
		}
	}

	public void func_28017_a(Container container1) {
		this.updateCraftingInventory(container1, container1.func_28127_b());
	}

	public void updateCraftingInventory(Container container1, List list2) {
		this.playerNetServerHandler.sendPacket(new Packet104WindowItems(container1.windowId, list2));
		this.playerNetServerHandler.sendPacket(new Packet103SetSlot(-1, -1, this.inventory.getItemStack()));
	}

	public void updateCraftingInventoryInfo(Container container1, int i2, int i3) {
		this.playerNetServerHandler.sendPacket(new Packet105UpdateProgressbar(container1.windowId, i2, i3));
	}

	public void onItemStackChanged(ItemStack itemStack1) {
	}

	public void usePersonalCraftingInventory() {
		this.playerNetServerHandler.sendPacket(new Packet101CloseWindow(this.currentCraftingInventory.windowId));
		this.closeCraftingGui();
	}

	public void y() {
		if(!this.isChangingQuantityOnly) {
			this.playerNetServerHandler.sendPacket(new Packet103SetSlot(-1, -1, this.inventory.getItemStack()));
		}
	}

	public void closeCraftingGui() {
		this.currentCraftingInventory.onCraftGuiClosed(this);
		this.currentCraftingInventory = this.personalCraftingInventory;
	}

	public void setMovementType(float f1, float f2, boolean z3, boolean z4, float f5, float f6) {
		this.moveStrafing = f1;
		this.moveForward = f2;
		this.isJumping = z3;
		this.setSneaking(z4);
		this.rotationPitch = f5;
		this.rotationYaw = f6;
	}

	public void addStat(StatBase statBase1, int i2) {
		if(statBase1 != null) {
			if(!statBase1.isIndependent) {
				while(i2 > 100) {
					this.playerNetServerHandler.sendPacket(new Packet200Statistic(statBase1.statId, 100));
					i2 -= 100;
				}

				this.playerNetServerHandler.sendPacket(new Packet200Statistic(statBase1.statId, i2));
			}

		}
	}

	public void func_30002_A() {
		if(this.ridingEntity != null) {
			this.mountEntity(this.ridingEntity);
		}

		if(this.riddenByEntity != null) {
			this.riddenByEntity.mountEntity(this);
		}

		if(this.sleeping) {
			this.wakeUpPlayer(true, false, false);
		}

	}

	public void func_30001_B() {
		this.lastHealth = -99999999;
	}

	public void addChatMessage(String string1) {
		StringTranslate stringTranslate2 = StringTranslate.getInstance();
		String string3 = stringTranslate2.translateKey(string1);
		this.playerNetServerHandler.sendPacket(new Packet3Chat(string3));
	}

	protected void func_35199_C() {
		this.playerNetServerHandler.sendPacket(new Packet38EntityStatus(this.entityId, (byte)9));
		super.func_35199_C();
	}

	public void func_35201_a(ItemStack itemStack1, int i2) {
		super.func_35201_a(itemStack1, i2);
		if(itemStack1 != null && itemStack1.getItem() != null && itemStack1.getItem().func_35406_b(itemStack1) == EnumAction.eat) {
			EntityTracker entityTracker3 = this.mcServer.getEntityTracker(this.dimension);
			entityTracker3.sendPacketToTrackedPlayersAndTrackedEntity(this, new Packet18Animation(this, 5));
		}

	}

	protected void func_35181_a(PotionEffect potionEffect1) {
		super.func_35181_a(potionEffect1);
		this.playerNetServerHandler.sendPacket(new Packet41EntityEffect(this.entityId, potionEffect1));
	}

	protected void func_35179_b(PotionEffect potionEffect1) {
		super.func_35179_b(potionEffect1);
		this.playerNetServerHandler.sendPacket(new Packet41EntityEffect(this.entityId, potionEffect1));
	}

	protected void func_35185_c(PotionEffect potionEffect1) {
		super.func_35185_c(potionEffect1);
		this.playerNetServerHandler.sendPacket(new Packet42RemoveEntityEffect(this.entityId, potionEffect1));
	}
}
