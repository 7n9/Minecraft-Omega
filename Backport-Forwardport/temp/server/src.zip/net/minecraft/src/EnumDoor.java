package net.minecraft.src;

public enum EnumDoor {
	OPENING,
	WOOD_DOOR,
	GRATES,
	IRON_DOOR;
}
