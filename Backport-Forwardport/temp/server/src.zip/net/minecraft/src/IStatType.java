package net.minecraft.src;

public interface IStatType {
}
