package net.minecraft.src;

public interface IProgressUpdate {
	void func_438_a(String string1);

	void displayLoadingString(String string1);

	void setLoadingProgress(int i1);
}
