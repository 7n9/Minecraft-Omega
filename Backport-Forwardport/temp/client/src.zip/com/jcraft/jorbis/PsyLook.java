package com.jcraft.jorbis;

class PsyLook {
	int n;
	PsyInfo vi;
	float[][][] tonecurves;
	float[][] peakatt;
	float[][][] noisecurves;
	float[] ath;
	int[] octave;

	void init(PsyInfo psyInfo1, int i2, int i3) {
	}
}
