package net.minecraft.src;

public abstract class ComponentVillageRoadPiece extends ComponentVillage {
	protected ComponentVillageRoadPiece(int i1) {
		super(i1);
	}
}
