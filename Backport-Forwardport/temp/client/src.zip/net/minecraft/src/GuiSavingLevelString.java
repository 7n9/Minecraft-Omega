package net.minecraft.src;

public class GuiSavingLevelString {
	public String field_35624_a;
	public int field_35623_b;

	public GuiSavingLevelString(String string1) {
		this.field_35624_a = string1;
	}
}
