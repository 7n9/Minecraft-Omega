package net.minecraft.src;

public class ItemMapBase extends Item {
	protected ItemMapBase(int i1) {
		super(i1);
	}
}
