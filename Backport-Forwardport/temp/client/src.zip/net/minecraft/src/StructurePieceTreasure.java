package net.minecraft.src;

public class StructurePieceTreasure extends WeightedRandomChoice {
	public int field_35596_a;
	public int field_35594_b;
	public int field_35595_c;
	public int field_35593_e;

	public StructurePieceTreasure(int i1, int i2, int i3, int i4, int i5) {
		super(i5);
		this.field_35596_a = i1;
		this.field_35594_b = i2;
		this.field_35595_c = i3;
		this.field_35593_e = i4;
	}
}
