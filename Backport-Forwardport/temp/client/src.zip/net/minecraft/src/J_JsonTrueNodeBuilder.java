package net.minecraft.src;

final class J_JsonTrueNodeBuilder implements J_JsonNodeBuilder {
	public J_JsonNode buildNode() {
		return J_JsonNodeFactories.func_27313_b();
	}
}
