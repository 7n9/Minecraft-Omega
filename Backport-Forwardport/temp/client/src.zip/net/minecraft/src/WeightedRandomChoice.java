package net.minecraft.src;

public class WeightedRandomChoice {
	protected int field_35590_d;

	public WeightedRandomChoice(int i1) {
		this.field_35590_d = i1;
	}
}
