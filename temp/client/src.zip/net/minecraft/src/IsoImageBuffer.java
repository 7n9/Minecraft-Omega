package net.minecraft.src;

import java.awt.image.BufferedImage;

public class IsoImageBuffer {
	public BufferedImage field_1348_a;
	public World worldObj;
	public int field_1354_c;
	public int field_1353_d;
	public boolean field_1352_e = false;
	public boolean field_1351_f = false;
	public int field_1350_g = 0;
	public boolean field_1349_h = false;

	public IsoImageBuffer(World world1, int i2, int i3) {
		this.worldObj = world1;
		this.func_889_a(i2, i3);
	}

	public void func_889_a(int i1, int i2) {
		this.field_1352_e = false;
		this.field_1354_c = i1;
		this.field_1353_d = i2;
		this.field_1350_g = 0;
		this.field_1349_h = false;
	}

	public void func_888_a(World world1, int i2, int i3) {
		this.worldObj = world1;
		this.func_889_a(i2, i3);
	}
}
