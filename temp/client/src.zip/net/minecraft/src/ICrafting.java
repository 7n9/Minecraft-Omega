package net.minecraft.src;

public interface ICrafting {
	void func_20159_a(Container container1, int i2, ItemStack itemStack3);

	void func_20158_a(Container container1, int i2, int i3);
}
