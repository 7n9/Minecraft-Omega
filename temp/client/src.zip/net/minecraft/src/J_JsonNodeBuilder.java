package net.minecraft.src;

public interface J_JsonNodeBuilder {
	J_JsonNode func_27234_b();
}
