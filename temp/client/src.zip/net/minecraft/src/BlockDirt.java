package net.minecraft.src;

public class BlockDirt extends Block {
	protected BlockDirt(int i1, int i2) {
		super(i1, i2, Material.ground);
	}
}
