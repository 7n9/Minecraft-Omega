package net.minecraft.src;

public class ModelBed {
	public static final int[] field_22154_a = new int[]{3, 4, 2, 5};
	public static final int[] field_22153_b = new int[]{2, 3, 0, 1};
	public static final int[][] field_22155_c = new int[][]{{1, 0, 3, 2, 5, 4}, {1, 0, 5, 4, 2, 3}, {1, 0, 2, 3, 4, 5}, {1, 0, 4, 5, 3, 2}};
}
