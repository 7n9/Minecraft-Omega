package net.minecraft.src;

class RedstoneUpdateInfo {
	int x;
	int y;
	int z;
	long updateTime;

	public RedstoneUpdateInfo(int i1, int i2, int i3, long j4) {
		this.x = i1;
		this.y = i2;
		this.z = i3;
		this.updateTime = j4;
	}
}
