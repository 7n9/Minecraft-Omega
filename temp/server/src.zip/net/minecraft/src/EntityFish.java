package net.minecraft.src;

import java.util.List;

public class EntityFish extends Entity {
	private int xTile = -1;
	private int yTile = -1;
	private int zTile = -1;
	private int inTile = 0;
	private boolean inGround = false;
	public int shake = 0;
	public EntityPlayer angler;
	private int ticksInGround;
	private int ticksInAir = 0;
	private int ticksCatchable = 0;
	public Entity bobber = null;
	private int field_6149_an;
	private double field_6148_ao;
	private double field_6147_ap;
	private double field_6146_aq;
	private double field_6145_ar;
	private double field_6144_as;

	public EntityFish(World world1) {
		super(world1);
		this.setSize(0.25F, 0.25F);
		this.field_28008_bI = true;
	}

	public EntityFish(World world1, EntityPlayer entityPlayer2) {
		super(world1);
		this.field_28008_bI = true;
		this.angler = entityPlayer2;
		this.angler.fishEntity = this;
		this.setSize(0.25F, 0.25F);
		this.setLocationAndAngles(entityPlayer2.posX, entityPlayer2.posY + 1.62D - (double)entityPlayer2.yOffset, entityPlayer2.posZ, entityPlayer2.rotationYaw, entityPlayer2.rotationPitch);
		this.posX -= (double)(MathHelper.cos(this.rotationYaw / 180.0F * 3.1415927F) * 0.16F);
		this.posY -= 0.10000000149011612D;
		this.posZ -= (double)(MathHelper.sin(this.rotationYaw / 180.0F * 3.1415927F) * 0.16F);
		this.setPosition(this.posX, this.posY, this.posZ);
		this.yOffset = 0.0F;
		float f3 = 0.4F;
		this.motionX = (double)(-MathHelper.sin(this.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(this.rotationPitch / 180.0F * 3.1415927F) * f3);
		this.motionZ = (double)(MathHelper.cos(this.rotationYaw / 180.0F * 3.1415927F) * MathHelper.cos(this.rotationPitch / 180.0F * 3.1415927F) * f3);
		this.motionY = (double)(-MathHelper.sin(this.rotationPitch / 180.0F * 3.1415927F) * f3);
		this.func_6142_a(this.motionX, this.motionY, this.motionZ, 1.5F, 1.0F);
	}

	protected void entityInit() {
	}

	public void func_6142_a(double d1, double d3, double d5, float f7, float f8) {
		float f9 = MathHelper.sqrt_double(d1 * d1 + d3 * d3 + d5 * d5);
		d1 /= (double)f9;
		d3 /= (double)f9;
		d5 /= (double)f9;
		d1 += this.rand.nextGaussian() * 0.007499999832361937D * (double)f8;
		d3 += this.rand.nextGaussian() * 0.007499999832361937D * (double)f8;
		d5 += this.rand.nextGaussian() * 0.007499999832361937D * (double)f8;
		d1 *= (double)f7;
		d3 *= (double)f7;
		d5 *= (double)f7;
		this.motionX = d1;
		this.motionY = d3;
		this.motionZ = d5;
		float f10 = MathHelper.sqrt_double(d1 * d1 + d5 * d5);
		this.prevRotationYaw = this.rotationYaw = (float)(Math.atan2(d1, d5) * 180.0D / 3.1415927410125732D);
		this.prevRotationPitch = this.rotationPitch = (float)(Math.atan2(d3, (double)f10) * 180.0D / 3.1415927410125732D);
		this.ticksInGround = 0;
	}

	public void onUpdate() {
		super.onUpdate();
		if(this.field_6149_an > 0) {
			double d21 = this.posX + (this.field_6148_ao - this.posX) / (double)this.field_6149_an;
			double d22 = this.posY + (this.field_6147_ap - this.posY) / (double)this.field_6149_an;
			double d23 = this.posZ + (this.field_6146_aq - this.posZ) / (double)this.field_6149_an;

			double d7;
			for(d7 = this.field_6145_ar - (double)this.rotationYaw; d7 < -180.0D; d7 += 360.0D) {
			}

			while(d7 >= 180.0D) {
				d7 -= 360.0D;
			}

			this.rotationYaw = (float)((double)this.rotationYaw + d7 / (double)this.field_6149_an);
			this.rotationPitch = (float)((double)this.rotationPitch + (this.field_6144_as - (double)this.rotationPitch) / (double)this.field_6149_an);
			--this.field_6149_an;
			this.setPosition(d21, d22, d23);
			this.setRotation(this.rotationYaw, this.rotationPitch);
		} else {
			if(!this.worldObj.singleplayerWorld) {
				ItemStack itemStack1 = this.angler.getCurrentEquippedItem();
				if(this.angler.isDead || !this.angler.isEntityAlive() || itemStack1 == null || itemStack1.getItem() != Item.fishingRod || this.getDistanceSqToEntity(this.angler) > 1024.0D) {
					this.setEntityDead();
					this.angler.fishEntity = null;
					return;
				}

				if(this.bobber != null) {
					if(!this.bobber.isDead) {
						this.posX = this.bobber.posX;
						this.posY = this.bobber.boundingBox.minY + (double)this.bobber.height * 0.8D;
						this.posZ = this.bobber.posZ;
						return;
					}

					this.bobber = null;
				}
			}

			if(this.shake > 0) {
				--this.shake;
			}

			if(this.inGround) {
				int i19 = this.worldObj.getBlockId(this.xTile, this.yTile, this.zTile);
				if(i19 == this.inTile) {
					++this.ticksInGround;
					if(this.ticksInGround == 1200) {
						this.setEntityDead();
					}

					return;
				}

				this.inGround = false;
				this.motionX *= (double)(this.rand.nextFloat() * 0.2F);
				this.motionY *= (double)(this.rand.nextFloat() * 0.2F);
				this.motionZ *= (double)(this.rand.nextFloat() * 0.2F);
				this.ticksInGround = 0;
				this.ticksInAir = 0;
			} else {
				++this.ticksInAir;
			}

			Vec3D vec3D20 = Vec3D.createVector(this.posX, this.posY, this.posZ);
			Vec3D vec3D2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
			MovingObjectPosition movingObjectPosition3 = this.worldObj.rayTraceBlocks(vec3D20, vec3D2);
			vec3D20 = Vec3D.createVector(this.posX, this.posY, this.posZ);
			vec3D2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
			if(movingObjectPosition3 != null) {
				vec3D2 = Vec3D.createVector(movingObjectPosition3.hitVec.xCoord, movingObjectPosition3.hitVec.yCoord, movingObjectPosition3.hitVec.zCoord);
			}

			Entity entity4 = null;
			List list5 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0D, 1.0D, 1.0D));
			double d6 = 0.0D;

			double d13;
			for(int i8 = 0; i8 < list5.size(); ++i8) {
				Entity entity9 = (Entity)list5.get(i8);
				if(entity9.canBeCollidedWith() && (entity9 != this.angler || this.ticksInAir >= 5)) {
					float f10 = 0.3F;
					AxisAlignedBB axisAlignedBB11 = entity9.boundingBox.expand((double)f10, (double)f10, (double)f10);
					MovingObjectPosition movingObjectPosition12 = axisAlignedBB11.func_706_a(vec3D20, vec3D2);
					if(movingObjectPosition12 != null) {
						d13 = vec3D20.distanceTo(movingObjectPosition12.hitVec);
						if(d13 < d6 || d6 == 0.0D) {
							entity4 = entity9;
							d6 = d13;
						}
					}
				}
			}

			if(entity4 != null) {
				movingObjectPosition3 = new MovingObjectPosition(entity4);
			}

			if(movingObjectPosition3 != null) {
				if(movingObjectPosition3.entityHit != null) {
					if(movingObjectPosition3.entityHit.attackEntityFrom(this.angler, 0)) {
						this.bobber = movingObjectPosition3.entityHit;
					}
				} else {
					this.inGround = true;
				}
			}

			if(!this.inGround) {
				this.moveEntity(this.motionX, this.motionY, this.motionZ);
				float f24 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
				this.rotationYaw = (float)(Math.atan2(this.motionX, this.motionZ) * 180.0D / 3.1415927410125732D);

				for(this.rotationPitch = (float)(Math.atan2(this.motionY, (double)f24) * 180.0D / 3.1415927410125732D); this.rotationPitch - this.prevRotationPitch < -180.0F; this.prevRotationPitch -= 360.0F) {
				}

				while(this.rotationPitch - this.prevRotationPitch >= 180.0F) {
					this.prevRotationPitch += 360.0F;
				}

				while(this.rotationYaw - this.prevRotationYaw < -180.0F) {
					this.prevRotationYaw -= 360.0F;
				}

				while(this.rotationYaw - this.prevRotationYaw >= 180.0F) {
					this.prevRotationYaw += 360.0F;
				}

				this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2F;
				this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2F;
				float f25 = 0.92F;
				if(this.onGround || this.isCollidedHorizontally) {
					f25 = 0.5F;
				}

				byte b26 = 5;
				double d27 = 0.0D;

				for(int i28 = 0; i28 < b26; ++i28) {
					double d14 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(i28 + 0) / (double)b26 - 0.125D + 0.125D;
					double d16 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(i28 + 1) / (double)b26 - 0.125D + 0.125D;
					AxisAlignedBB axisAlignedBB18 = AxisAlignedBB.getBoundingBoxFromPool(this.boundingBox.minX, d14, this.boundingBox.minZ, this.boundingBox.maxX, d16, this.boundingBox.maxZ);
					if(this.worldObj.isAABBInMaterial(axisAlignedBB18, Material.water)) {
						d27 += 1.0D / (double)b26;
					}
				}

				if(d27 > 0.0D) {
					if(this.ticksCatchable > 0) {
						--this.ticksCatchable;
					} else {
						short s29 = 500;
						if(this.worldObj.canLightningStrikeAt(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY) + 1, MathHelper.floor_double(this.posZ))) {
							s29 = 300;
						}

						if(this.rand.nextInt(s29) == 0) {
							this.ticksCatchable = this.rand.nextInt(30) + 10;
							this.motionY -= 0.20000000298023224D;
							this.worldObj.playSoundAtEntity(this, "random.splash", 0.25F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
							float f30 = (float)MathHelper.floor_double(this.boundingBox.minY);

							int i15;
							float f17;
							float f31;
							for(i15 = 0; (float)i15 < 1.0F + this.width * 20.0F; ++i15) {
								f31 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
								f17 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
								this.worldObj.spawnParticle("bubble", this.posX + (double)f31, (double)(f30 + 1.0F), this.posZ + (double)f17, this.motionX, this.motionY - (double)(this.rand.nextFloat() * 0.2F), this.motionZ);
							}

							for(i15 = 0; (float)i15 < 1.0F + this.width * 20.0F; ++i15) {
								f31 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
								f17 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
								this.worldObj.spawnParticle("splash", this.posX + (double)f31, (double)(f30 + 1.0F), this.posZ + (double)f17, this.motionX, this.motionY, this.motionZ);
							}
						}
					}
				}

				if(this.ticksCatchable > 0) {
					this.motionY -= (double)(this.rand.nextFloat() * this.rand.nextFloat() * this.rand.nextFloat()) * 0.2D;
				}

				d13 = d27 * 2.0D - 1.0D;
				this.motionY += 0.03999999910593033D * d13;
				if(d27 > 0.0D) {
					f25 = (float)((double)f25 * 0.9D);
					this.motionY *= 0.8D;
				}

				this.motionX *= (double)f25;
				this.motionY *= (double)f25;
				this.motionZ *= (double)f25;
				this.setPosition(this.posX, this.posY, this.posZ);
			}
		}
	}

	public void writeEntityToNBT(NBTTagCompound nBTTagCompound1) {
		nBTTagCompound1.setShort("xTile", (short)this.xTile);
		nBTTagCompound1.setShort("yTile", (short)this.yTile);
		nBTTagCompound1.setShort("zTile", (short)this.zTile);
		nBTTagCompound1.setByte("inTile", (byte)this.inTile);
		nBTTagCompound1.setByte("shake", (byte)this.shake);
		nBTTagCompound1.setByte("inGround", (byte)(this.inGround ? 1 : 0));
	}

	public void readEntityFromNBT(NBTTagCompound nBTTagCompound1) {
		this.xTile = nBTTagCompound1.getShort("xTile");
		this.yTile = nBTTagCompound1.getShort("yTile");
		this.zTile = nBTTagCompound1.getShort("zTile");
		this.inTile = nBTTagCompound1.getByte("inTile") & 255;
		this.shake = nBTTagCompound1.getByte("shake") & 255;
		this.inGround = nBTTagCompound1.getByte("inGround") == 1;
	}

	public int catchFish() {
		byte b1 = 0;
		if(this.bobber != null) {
			double d2 = this.angler.posX - this.posX;
			double d4 = this.angler.posY - this.posY;
			double d6 = this.angler.posZ - this.posZ;
			double d8 = (double)MathHelper.sqrt_double(d2 * d2 + d4 * d4 + d6 * d6);
			double d10 = 0.1D;
			this.bobber.motionX += d2 * d10;
			this.bobber.motionY += d4 * d10 + (double)MathHelper.sqrt_double(d8) * 0.08D;
			this.bobber.motionZ += d6 * d10;
			b1 = 3;
		} else if(this.ticksCatchable > 0) {
			EntityItem entityItem13 = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(Item.fishRaw));
			double d3 = this.angler.posX - this.posX;
			double d5 = this.angler.posY - this.posY;
			double d7 = this.angler.posZ - this.posZ;
			double d9 = (double)MathHelper.sqrt_double(d3 * d3 + d5 * d5 + d7 * d7);
			double d11 = 0.1D;
			entityItem13.motionX = d3 * d11;
			entityItem13.motionY = d5 * d11 + (double)MathHelper.sqrt_double(d9) * 0.08D;
			entityItem13.motionZ = d7 * d11;
			this.worldObj.entityJoinedWorld(entityItem13);
			this.angler.addStat(StatList.fishCaughtStat, 1);
			b1 = 1;
		}

		if(this.inGround) {
			b1 = 2;
		}

		this.setEntityDead();
		this.angler.fishEntity = null;
		return b1;
	}
}
