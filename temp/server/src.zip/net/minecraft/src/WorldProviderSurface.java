package net.minecraft.src;

public class WorldProviderSurface extends WorldProvider {
}
