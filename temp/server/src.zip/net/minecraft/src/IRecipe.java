package net.minecraft.src;

public interface IRecipe {
	boolean func_21134_a(InventoryCrafting inventoryCrafting1);

	ItemStack func_21136_b(InventoryCrafting inventoryCrafting1);

	int getRecipeSize();

	ItemStack func_25077_b();
}
