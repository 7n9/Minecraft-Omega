package net.minecraft.src;

final class StatTypeSimple implements IStatType {
}
